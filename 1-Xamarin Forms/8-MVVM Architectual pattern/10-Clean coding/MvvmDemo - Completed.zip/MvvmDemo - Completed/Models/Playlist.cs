﻿namespace MvvmDemo
{
	public class Playlist
	{
		public string Title { get; set; }
		public bool IsFavorite { get; set; }
	}
}
