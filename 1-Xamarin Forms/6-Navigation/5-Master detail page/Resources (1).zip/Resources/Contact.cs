﻿namespace HelloWorld
{
	public class Contact
	{
		public string Name { get; set; }
		public string Status { get; set; }
		public string ImageUrl { get; set; }
	}
}

